import React from 'react'

export const NewPassword = () => {
  return <div>NewPassword</div>
}
