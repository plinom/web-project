// App.js
import React from 'react';
import ParentComponent from '../components/Parent';

const Fetch = () => {
  return (
    <div>
      <h1>Simple React Page</h1>
      <ParentComponent />
    </div>
  );
};

export default Fetch;
